#!/bin/bash
# Discord Automation Tool Runner
cd /app
python discord_tool.py
