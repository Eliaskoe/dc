#!/usr/bin/env python3
"""
Discord Automation Tool - Console Application
Uses Discord USER token (not bot token) for automation
"""

import asyncio
import aiohttp
import json
import os
import sys
import time
import random
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.live import Live
from rich.layout import Layout
from rich.text import Text
from rich.style import Style
from rich import box
from rich.markdown import Markdown

# Initialize Rich console
console = Console()

# Discord API base URL
DISCORD_API = "https://discord.com/api/v10"

# Configuration
CONFIG_FILE = Path("discord_config.json")
EXPORT_DIR = Path("exports")
LOGS_DIR = Path("logs")

class DiscordClient:
    """Discord client using user token"""
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        self.session: Optional[aiohttp.ClientSession] = None
        self.user_info: Optional[Dict] = None
        self.guilds: List[Dict] = []
        self.rate_limit_remaining = 5
        self.rate_limit_reset = 0
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(headers=self.headers)
        return self
    
    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()
    
    async def _handle_rate_limit(self, response: aiohttp.ClientResponse):
        """Handle Discord rate limits"""
        if response.status == 429:
            retry_after = float(response.headers.get("Retry-After", 5))
            console.print(f"[yellow]⚠ Rate limited. Waiting {retry_after}s...[/yellow]")
            await asyncio.sleep(retry_after)
            return True
        
        self.rate_limit_remaining = int(response.headers.get("X-RateLimit-Remaining", 5))
        self.rate_limit_reset = float(response.headers.get("X-RateLimit-Reset", 0))
        
        if self.rate_limit_remaining <= 1:
            wait_time = max(0, self.rate_limit_reset - time.time())
            if wait_time > 0:
                await asyncio.sleep(wait_time + 0.5)
        return False
    
    async def _request(self, method: str, endpoint: str, **kwargs) -> Optional[Dict]:
        """Make API request with rate limit handling"""
        url = f"{DISCORD_API}{endpoint}"
        
        for attempt in range(3):
            try:
                async with self.session.request(method, url, **kwargs) as response:
                    if await self._handle_rate_limit(response):
                        continue
                    
                    if response.status == 200:
                        return await response.json()
                    elif response.status == 204:
                        return {}
                    elif response.status == 401:
                        console.print("[red]✖ Invalid token![/red]")
                        return None
                    elif response.status == 403:
                        console.print(f"[red]✖ Forbidden: {endpoint}[/red]")
                        return None
                    else:
                        text = await response.text()
                        console.print(f"[red]✖ Error {response.status}: {text[:100]}[/red]")
                        return None
            except Exception as e:
                console.print(f"[red]✖ Request error: {e}[/red]")
                await asyncio.sleep(1)
        
        return None
    
    async def login(self) -> bool:
        """Verify token and get user info"""
        self.user_info = await self._request("GET", "/users/@me")
        if self.user_info:
            return True
        return False
    
    async def get_guilds(self) -> List[Dict]:
        """Get all guilds (servers) user is member of"""
        guilds = await self._request("GET", "/users/@me/guilds")
        if guilds:
            self.guilds = guilds
        return self.guilds
    
    async def get_guild_channels(self, guild_id: str) -> List[Dict]:
        """Get all channels in a guild"""
        channels = await self._request("GET", f"/guilds/{guild_id}/channels")
        return channels or []
    
    async def get_guild_members(self, guild_id: str, limit: int = 1000) -> List[Dict]:
        """Get members of a guild (limited by Discord)"""
        members = []
        after = "0"
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("[progress.percentage]{task.completed}/{task.total}"),
            console=console
        ) as progress:
            task = progress.add_task("[cyan]Fetching members...", total=limit)
            
            while len(members) < limit:
                chunk = await self._request(
                    "GET", 
                    f"/guilds/{guild_id}/members",
                    params={"limit": min(1000, limit - len(members)), "after": after}
                )
                
                if not chunk:
                    break
                
                members.extend(chunk)
                progress.update(task, completed=len(members))
                
                if len(chunk) < 1000:
                    break
                
                after = chunk[-1]["user"]["id"]
                await asyncio.sleep(0.5)
        
        return members
    
    async def search_guild_members(self, guild_id: str, query: str = "", limit: int = 100) -> List[Dict]:
        """Search guild members by username"""
        members = await self._request(
            "GET",
            f"/guilds/{guild_id}/members/search",
            params={"query": query, "limit": min(1000, limit)}
        )
        return members or []
    
    async def send_message(self, channel_id: str, content: str) -> Optional[Dict]:
        """Send a message to a channel"""
        return await self._request(
            "POST",
            f"/channels/{channel_id}/messages",
            json={"content": content}
        )
    
    async def get_channel_messages(self, channel_id: str, limit: int = 100) -> List[Dict]:
        """Get messages from a channel"""
        messages = await self._request(
            "GET",
            f"/channels/{channel_id}/messages",
            params={"limit": min(100, limit)}
        )
        return messages or []


class DiscordTool:
    """Main Discord Automation Tool"""
    
    def __init__(self):
        self.client: Optional[DiscordClient] = None
        self.config = self._load_config()
        self.selected_guild: Optional[Dict] = None
        self.selected_channels: List[Dict] = []
        self.automation_tasks: List[asyncio.Task] = []
        self.running = True
        
        # Create directories
        EXPORT_DIR.mkdir(exist_ok=True)
        LOGS_DIR.mkdir(exist_ok=True)
    
    def _load_config(self) -> Dict:
        """Load configuration from file"""
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE) as f:
                return json.load(f)
        return {
            "token": "",
            "message_delay_min": 30,
            "message_delay_max": 60,
            "auto_reply_triggers": {},
            "message_templates": []
        }
    
    def _save_config(self):
        """Save configuration to file"""
        with open(CONFIG_FILE, "w") as f:
            json.dump(self.config, f, indent=2)
    
    def _log_action(self, action: str, details: str = ""):
        """Log an action to file"""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_file = LOGS_DIR / f"log_{datetime.now().strftime('%Y%m%d')}.txt"
        with open(log_file, "a") as f:
            f.write(f"[{timestamp}] {action}: {details}\n")
    
    def show_banner(self):
        """Display the application banner"""
        banner = """
██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ██████╗     ████████╗ ██████╗  ██████╗ ██╗     
██╔══██╗██║██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔══██╗    ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
██║  ██║██║███████╗██║     ██║   ██║██████╔╝██║  ██║       ██║   ██║   ██║██║   ██║██║     
██║  ██║██║╚════██║██║     ██║   ██║██╔══██╗██║  ██║       ██║   ██║   ██║██║   ██║██║     
██████╔╝██║███████║╚██████╗╚██████╔╝██║  ██║██████╔╝       ██║   ╚██████╔╝╚██████╔╝███████╗
╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝        ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
        """
        console.print(Panel(
            Text(banner, style="bold cyan"),
            title="[bold magenta]Discord Automation Tool[/bold magenta]",
            subtitle="[dim]User Token Edition[/dim]",
            border_style="blue"
        ))
    
    def show_main_menu(self) -> str:
        """Display main menu and get selection"""
        menu = Table(box=box.ROUNDED, show_header=False, border_style="cyan")
        menu.add_column("Option", style="bold yellow", width=5)
        menu.add_column("Description", style="white")
        
        options = [
            ("1", "🔐 Set/Change Token"),
            ("2", "🖥️  Select Server"),
            ("3", "📋 Extract Users to TXT"),
            ("4", "💬 Send Message"),
            ("5", "⏰ Schedule Messages"),
            ("6", "📢 Mass Message (All Channels)"),
            ("7", "🤖 Auto-Reply Setup"),
            ("8", "📝 Message Templates"),
            ("9", "📊 View Activity Logs"),
            ("10", "⚙️  Settings"),
            ("0", "🚪 Exit"),
        ]
        
        for opt, desc in options:
            menu.add_row(f"[{opt}]", desc)
        
        console.print(Panel(menu, title="[bold green]Main Menu[/bold green]", border_style="green"))
        
        if self.client and self.client.user_info:
            user = self.client.user_info
            console.print(f"[green]✓ Logged in as:[/green] [bold cyan]{user['username']}#{user.get('discriminator', '0')}[/bold cyan]")
        
        if self.selected_guild:
            console.print(f"[green]✓ Selected server:[/green] [bold magenta]{self.selected_guild['name']}[/bold magenta]")
        
        return Prompt.ask("\n[bold yellow]Select option[/bold yellow]", default="0")
    
    async def set_token(self):
        """Set or change Discord token"""
        console.print(Panel(
            "[yellow]Enter your Discord USER token (not bot token)\n"
            "[dim]To get your token: Open Discord in browser → F12 → Network tab → "
            "Find any request → Copy 'authorization' header[/dim]",
            title="Token Setup",
            border_style="yellow"
        ))
        
        token = Prompt.ask("[bold]Token[/bold]", password=True)
        
        if not token:
            console.print("[red]✖ No token provided[/red]")
            return
        
        with console.status("[bold cyan]Verifying token...[/bold cyan]"):
            async with DiscordClient(token) as client:
                if await client.login():
                    self.client = client
                    self.config["token"] = token
                    self._save_config()
                    
                    user = client.user_info
                    console.print(Panel(
                        f"[green]✓ Successfully logged in![/green]\n\n"
                        f"[bold]Username:[/bold] {user['username']}#{user.get('discriminator', '0')}\n"
                        f"[bold]User ID:[/bold] {user['id']}\n"
                        f"[bold]Email:[/bold] {user.get('email', 'N/A')}",
                        title="Login Successful",
                        border_style="green"
                    ))
                    self._log_action("LOGIN", f"User: {user['username']}")
                else:
                    console.print("[red]✖ Invalid token! Please try again.[/red]")
    
    async def select_server(self):
        """Select a Discord server"""
        if not self.client:
            console.print("[red]✖ Please set token first![/red]")
            return
        
        with console.status("[bold cyan]Fetching servers...[/bold cyan]"):
            guilds = await self.client.get_guilds()
        
        if not guilds:
            console.print("[red]✖ No servers found or failed to fetch[/red]")
            return
        
        table = Table(title="Your Servers", box=box.ROUNDED, border_style="cyan")
        table.add_column("#", style="bold yellow", width=4)
        table.add_column("Server Name", style="bold white")
        table.add_column("Server ID", style="dim")
        table.add_column("Members", style="cyan")
        table.add_column("Owner", style="magenta")
        
        for i, guild in enumerate(guilds, 1):
            table.add_row(
                str(i),
                guild["name"][:30],
                guild["id"],
                str(guild.get("approximate_member_count", "?")),
                "✓" if guild.get("owner") else ""
            )
        
        console.print(table)
        
        choice = IntPrompt.ask(
            "[bold yellow]Select server number[/bold yellow]",
            default=1
        )
        
        if 1 <= choice <= len(guilds):
            self.selected_guild = guilds[choice - 1]
            console.print(f"[green]✓ Selected: {self.selected_guild['name']}[/green]")
            self._log_action("SELECT_SERVER", self.selected_guild['name'])
        else:
            console.print("[red]✖ Invalid selection[/red]")
    
    async def extract_users(self):
        """Extract users from selected server to TXT file"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Please set token and select a server first![/red]")
            return
        
        console.print(Panel(
            "[cyan]User Extraction Options[/cyan]\n\n"
            "[1] Extract all members (may be limited by Discord)\n"
            "[2] Search members by name\n"
            "[3] Extract from channel message history",
            title="Extract Users",
            border_style="cyan"
        ))
        
        method = Prompt.ask("[bold]Method[/bold]", choices=["1", "2", "3"], default="1")
        
        members = []
        
        if method == "1":
            limit = IntPrompt.ask("[bold]Max members to fetch[/bold]", default=1000)
            members = await self.client.get_guild_members(self.selected_guild["id"], limit)
        
        elif method == "2":
            query = Prompt.ask("[bold]Search query[/bold]", default="")
            limit = IntPrompt.ask("[bold]Max results[/bold]", default=100)
            members = await self.client.search_guild_members(self.selected_guild["id"], query, limit)
        
        elif method == "3":
            channels = await self.client.get_guild_channels(self.selected_guild["id"])
            text_channels = [c for c in channels if c["type"] == 0]
            
            if not text_channels:
                console.print("[red]✖ No text channels found[/red]")
                return
            
            console.print("\n[bold]Text Channels:[/bold]")
            for i, ch in enumerate(text_channels[:20], 1):
                console.print(f"  [{i}] #{ch['name']}")
            
            ch_choice = IntPrompt.ask("[bold]Select channel[/bold]", default=1)
            if 1 <= ch_choice <= len(text_channels):
                channel = text_channels[ch_choice - 1]
                messages = await self.client.get_channel_messages(channel["id"], 100)
                
                seen_users = set()
                for msg in messages:
                    user = msg.get("author", {})
                    if user.get("id") and user["id"] not in seen_users:
                        seen_users.add(user["id"])
                        members.append({"user": user})
        
        if not members:
            console.print("[yellow]⚠ No members found[/yellow]")
            return
        
        # Export to TXT
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = EXPORT_DIR / f"{self.selected_guild['name']}_{timestamp}.txt"
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"# Server: {self.selected_guild['name']}\n")
            f.write(f"# Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"# Total Users: {len(members)}\n")
            f.write(f"# Format: username:userid:additional_info\n")
            f.write("=" * 60 + "\n\n")
            
            for member in members:
                user = member.get("user", member)
                username = user.get("username", "unknown")
                user_id = user.get("id", "unknown")
                discriminator = user.get("discriminator", "0")
                
                # Additional info
                info_parts = []
                if member.get("nick"):
                    info_parts.append(f"nick={member['nick']}")
                if user.get("bot"):
                    info_parts.append("bot=true")
                if member.get("joined_at"):
                    info_parts.append(f"joined={member['joined_at'][:10]}")
                if member.get("roles"):
                    info_parts.append(f"roles={len(member['roles'])}")
                
                additional_info = "|".join(info_parts) if info_parts else "none"
                
                f.write(f"{username}#{discriminator}:{user_id}:{additional_info}\n")
        
        console.print(Panel(
            f"[green]✓ Exported {len(members)} users[/green]\n\n"
            f"[bold]File:[/bold] {filename}",
            title="Export Complete",
            border_style="green"
        ))
        self._log_action("EXPORT_USERS", f"{len(members)} users to {filename}")
    
    async def send_single_message(self):
        """Send a single message to a channel"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Please set token and select a server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c["type"] == 0]
        
        if not text_channels:
            console.print("[red]✖ No text channels found[/red]")
            return
        
        table = Table(title="Text Channels", box=box.ROUNDED, border_style="cyan")
        table.add_column("#", style="bold yellow", width=4)
        table.add_column("Channel", style="white")
        table.add_column("ID", style="dim")
        
        for i, ch in enumerate(text_channels, 1):
            table.add_row(str(i), f"#{ch['name']}", ch["id"])
        
        console.print(table)
        
        ch_choice = IntPrompt.ask("[bold]Select channel[/bold]", default=1)
        
        if not (1 <= ch_choice <= len(text_channels)):
            console.print("[red]✖ Invalid selection[/red]")
            return
        
        channel = text_channels[ch_choice - 1]
        
        # Show templates if available
        if self.config.get("message_templates"):
            console.print("\n[bold]Message Templates:[/bold]")
            for i, tmpl in enumerate(self.config["message_templates"], 1):
                console.print(f"  [{i}] {tmpl[:50]}...")
            console.print(f"  [0] Type custom message")
            
            tmpl_choice = IntPrompt.ask("[bold]Select template or 0 for custom[/bold]", default=0)
            if 1 <= tmpl_choice <= len(self.config["message_templates"]):
                content = self.config["message_templates"][tmpl_choice - 1]
            else:
                content = Prompt.ask("[bold]Message[/bold]")
        else:
            content = Prompt.ask("[bold]Message[/bold]")
        
        if not content:
            console.print("[red]✖ No message provided[/red]")
            return
        
        result = await self.client.send_message(channel["id"], content)
        
        if result:
            console.print(f"[green]✓ Message sent to #{channel['name']}[/green]")
            self._log_action("SEND_MESSAGE", f"#{channel['name']}: {content[:50]}")
        else:
            console.print("[red]✖ Failed to send message[/red]")
    
    async def schedule_messages(self):
        """Schedule automated messages"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Please set token and select a server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c["type"] == 0]
        
        console.print(Panel(
            "[cyan]Schedule Messages[/cyan]\n\n"
            "Configure automated messages to be sent at intervals.\n"
            "[yellow]⚠ Messages are randomized within the delay range to appear natural[/yellow]",
            title="Message Scheduler",
            border_style="cyan"
        ))
        
        # Select channels
        table = Table(box=box.ROUNDED)
        table.add_column("#", style="yellow")
        table.add_column("Channel", style="white")
        
        for i, ch in enumerate(text_channels, 1):
            table.add_row(str(i), f"#{ch['name']}")
        
        console.print(table)
        
        selection = Prompt.ask(
            "[bold]Select channels (comma-separated, or 'all')[/bold]",
            default="1"
        )
        
        if selection.lower() == "all":
            selected = text_channels
        else:
            indices = [int(x.strip()) - 1 for x in selection.split(",") if x.strip().isdigit()]
            selected = [text_channels[i] for i in indices if 0 <= i < len(text_channels)]
        
        if not selected:
            console.print("[red]✖ No channels selected[/red]")
            return
        
        console.print(f"[green]✓ Selected {len(selected)} channel(s)[/green]")
        
        # Get message
        content = Prompt.ask("[bold]Message to send[/bold]")
        
        if not content:
            console.print("[red]✖ No message provided[/red]")
            return
        
        # Get timing
        delay_min = IntPrompt.ask("[bold]Minimum delay (seconds)[/bold]", default=30)
        delay_max = IntPrompt.ask("[bold]Maximum delay (seconds)[/bold]", default=60)
        count = IntPrompt.ask("[bold]Number of messages (0 for infinite)[/bold]", default=5)
        
        console.print(Panel(
            f"[bold]Configuration:[/bold]\n"
            f"Channels: {len(selected)}\n"
            f"Message: {content[:50]}...\n"
            f"Delay: {delay_min}-{delay_max}s\n"
            f"Count: {'Infinite' if count == 0 else count}",
            title="Confirm",
            border_style="yellow"
        ))
        
        if not Confirm.ask("[bold]Start scheduled messaging?[/bold]"):
            return
        
        # Start scheduling
        sent = 0
        target = count if count > 0 else float('inf')
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            console=console
        ) as progress:
            task = progress.add_task("[cyan]Sending messages...", total=count if count > 0 else 100)
            
            while sent < target:
                for channel in selected:
                    if sent >= target:
                        break
                    
                    result = await self.client.send_message(channel["id"], content)
                    
                    if result:
                        sent += 1
                        progress.update(task, completed=sent if count > 0 else sent % 100)
                        self._log_action("SCHEDULED_MSG", f"#{channel['name']}: {content[:30]}")
                    
                    delay = random.uniform(delay_min, delay_max)
                    await asyncio.sleep(delay)
        
        console.print(f"[green]✓ Sent {sent} messages[/green]")
    
    async def mass_message(self):
        """Send message to all channels in server"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Please set token and select a server first![/red]")
            return
        
        console.print(Panel(
            "[red]⚠ WARNING: Mass messaging all channels![/red]\n\n"
            "This will send a message to EVERY text channel.\n"
            "Use responsibly to avoid getting banned.",
            title="Mass Message",
            border_style="red"
        ))
        
        if not Confirm.ask("[bold red]Are you sure?[/bold red]"):
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c["type"] == 0]
        
        console.print(f"[cyan]Found {len(text_channels)} text channels[/cyan]")
        
        content = Prompt.ask("[bold]Message[/bold]")
        
        if not content:
            return
        
        delay = IntPrompt.ask("[bold]Delay between channels (seconds)[/bold]", default=5)
        
        sent = 0
        failed = 0
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TextColumn("{task.completed}/{task.total}"),
            console=console
        ) as progress:
            task = progress.add_task("[cyan]Mass messaging...", total=len(text_channels))
            
            for channel in text_channels:
                result = await self.client.send_message(channel["id"], content)
                
                if result:
                    sent += 1
                else:
                    failed += 1
                
                progress.update(task, advance=1, description=f"[cyan]#{channel['name'][:15]}")
                await asyncio.sleep(delay)
        
        console.print(Panel(
            f"[green]✓ Sent: {sent}[/green]\n"
            f"[red]✖ Failed: {failed}[/red]",
            title="Mass Message Complete",
            border_style="green"
        ))
        self._log_action("MASS_MESSAGE", f"Sent to {sent}/{len(text_channels)} channels")
    
    async def setup_auto_reply(self):
        """Configure auto-reply triggers"""
        console.print(Panel(
            "[cyan]Auto-Reply Configuration[/cyan]\n\n"
            "Set up automatic replies based on trigger words.\n"
            "[yellow]Note: Requires keeping the tool running[/yellow]",
            title="Auto-Reply",
            border_style="cyan"
        ))
        
        # Show existing triggers
        if self.config.get("auto_reply_triggers"):
            table = Table(title="Current Triggers", box=box.ROUNDED)
            table.add_column("Trigger", style="yellow")
            table.add_column("Response", style="white")
            
            for trigger, response in self.config["auto_reply_triggers"].items():
                table.add_row(trigger, response[:50] + "..." if len(response) > 50 else response)
            
            console.print(table)
        
        console.print("\n[1] Add trigger")
        console.print("[2] Remove trigger")
        console.print("[3] Clear all triggers")
        console.print("[0] Back")
        
        choice = Prompt.ask("[bold]Option[/bold]", choices=["0", "1", "2", "3"], default="0")
        
        if choice == "1":
            trigger = Prompt.ask("[bold]Trigger word/phrase[/bold]").lower()
            response = Prompt.ask("[bold]Auto-reply message[/bold]")
            
            if trigger and response:
                if "auto_reply_triggers" not in self.config:
                    self.config["auto_reply_triggers"] = {}
                self.config["auto_reply_triggers"][trigger] = response
                self._save_config()
                console.print(f"[green]✓ Added trigger: {trigger}[/green]")
        
        elif choice == "2":
            if self.config.get("auto_reply_triggers"):
                trigger = Prompt.ask("[bold]Trigger to remove[/bold]")
                if trigger in self.config["auto_reply_triggers"]:
                    del self.config["auto_reply_triggers"][trigger]
                    self._save_config()
                    console.print(f"[green]✓ Removed trigger: {trigger}[/green]")
        
        elif choice == "3":
            self.config["auto_reply_triggers"] = {}
            self._save_config()
            console.print("[green]✓ Cleared all triggers[/green]")
    
    async def manage_templates(self):
        """Manage message templates"""
        console.print(Panel(
            "[cyan]Message Templates[/cyan]\n\n"
            "Create reusable message templates with variables.\n"
            "[dim]Variables: {username}, {server}, {date}, {time}[/dim]",
            title="Templates",
            border_style="cyan"
        ))
        
        # Show existing templates
        if self.config.get("message_templates"):
            console.print("[bold]Current Templates:[/bold]")
            for i, tmpl in enumerate(self.config["message_templates"], 1):
                console.print(f"  [{i}] {tmpl[:60]}...")
        
        console.print("\n[1] Add template")
        console.print("[2] Remove template")
        console.print("[3] Clear all")
        console.print("[0] Back")
        
        choice = Prompt.ask("[bold]Option[/bold]", choices=["0", "1", "2", "3"], default="0")
        
        if choice == "1":
            template = Prompt.ask("[bold]Template message[/bold]")
            if template:
                if "message_templates" not in self.config:
                    self.config["message_templates"] = []
                self.config["message_templates"].append(template)
                self._save_config()
                console.print("[green]✓ Template added[/green]")
        
        elif choice == "2":
            if self.config.get("message_templates"):
                idx = IntPrompt.ask("[bold]Template number to remove[/bold]", default=1)
                if 1 <= idx <= len(self.config["message_templates"]):
                    self.config["message_templates"].pop(idx - 1)
                    self._save_config()
                    console.print("[green]✓ Template removed[/green]")
        
        elif choice == "3":
            self.config["message_templates"] = []
            self._save_config()
            console.print("[green]✓ All templates cleared[/green]")
    
    def view_logs(self):
        """View activity logs"""
        log_files = list(LOGS_DIR.glob("log_*.txt"))
        
        if not log_files:
            console.print("[yellow]No logs found[/yellow]")
            return
        
        log_files.sort(reverse=True)
        latest = log_files[0]
        
        console.print(Panel(
            f"[bold]Log File:[/bold] {latest.name}",
            title="Activity Logs",
            border_style="cyan"
        ))
        
        with open(latest) as f:
            lines = f.readlines()[-50:]  # Last 50 lines
        
        for line in lines:
            if "ERROR" in line or "FAIL" in line:
                console.print(f"[red]{line.strip()}[/red]")
            elif "SUCCESS" in line or "✓" in line:
                console.print(f"[green]{line.strip()}[/green]")
            else:
                console.print(f"[dim]{line.strip()}[/dim]")
    
    async def settings(self):
        """Configure settings"""
        console.print(Panel(
            "[cyan]Settings[/cyan]\n\n"
            f"[1] Message delay: {self.config.get('message_delay_min', 30)}-{self.config.get('message_delay_max', 60)}s\n"
            "[2] Clear saved token\n"
            "[3] Export config\n"
            "[0] Back",
            title="Settings",
            border_style="cyan"
        ))
        
        choice = Prompt.ask("[bold]Option[/bold]", choices=["0", "1", "2", "3"], default="0")
        
        if choice == "1":
            self.config["message_delay_min"] = IntPrompt.ask("[bold]Min delay (seconds)[/bold]", default=30)
            self.config["message_delay_max"] = IntPrompt.ask("[bold]Max delay (seconds)[/bold]", default=60)
            self._save_config()
            console.print("[green]✓ Settings saved[/green]")
        
        elif choice == "2":
            self.config["token"] = ""
            self._save_config()
            self.client = None
            console.print("[green]✓ Token cleared[/green]")
        
        elif choice == "3":
            console.print(f"[cyan]Config saved to: {CONFIG_FILE.absolute()}[/cyan]")
    
    async def run(self):
        """Main application loop"""
        self.show_banner()
        
        # Auto-login if token exists
        if self.config.get("token"):
            console.print("[cyan]Found saved token, logging in...[/cyan]")
            async with DiscordClient(self.config["token"]) as client:
                if await client.login():
                    self.client = client
                    console.print(f"[green]✓ Logged in as {client.user_info['username']}[/green]")
                    
                    # Keep client alive for the session
                    while self.running:
                        try:
                            choice = self.show_main_menu()
                            
                            if choice == "0":
                                self.running = False
                            elif choice == "1":
                                await self.set_token()
                            elif choice == "2":
                                await self.select_server()
                            elif choice == "3":
                                await self.extract_users()
                            elif choice == "4":
                                await self.send_single_message()
                            elif choice == "5":
                                await self.schedule_messages()
                            elif choice == "6":
                                await self.mass_message()
                            elif choice == "7":
                                await self.setup_auto_reply()
                            elif choice == "8":
                                await self.manage_templates()
                            elif choice == "9":
                                self.view_logs()
                            elif choice == "10":
                                await self.settings()
                            else:
                                console.print("[yellow]Invalid option[/yellow]")
                            
                            if self.running:
                                input("\nPress Enter to continue...")
                                console.clear()
                                self.show_banner()
                        
                        except KeyboardInterrupt:
                            console.print("\n[yellow]Interrupted. Exiting...[/yellow]")
                            self.running = False
                    
                    return
        
        # No saved token, prompt for one
        while self.running:
            try:
                choice = self.show_main_menu()
                
                if choice == "0":
                    self.running = False
                elif choice == "1":
                    await self.set_token()
                    if self.client:
                        # Restart with logged in client
                        await self.run()
                        return
                else:
                    console.print("[yellow]Please set token first (option 1)[/yellow]")
                
                if self.running:
                    input("\nPress Enter to continue...")
                    console.clear()
                    self.show_banner()
            
            except KeyboardInterrupt:
                console.print("\n[yellow]Interrupted. Exiting...[/yellow]")
                self.running = False
        
        console.print(Panel(
            "[bold green]Thanks for using Discord Tool![/bold green]\n"
            "[dim]Stay safe and use responsibly[/dim]",
            border_style="green"
        ))


async def main():
    """Entry point"""
    tool = DiscordTool()
    await tool.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nGoodbye!")
