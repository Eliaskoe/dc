#!/usr/bin/env python3
"""
Discord Automation Tool - ULTIMATE Edition
Uses Discord USER token for full automation
"""

import asyncio
import aiohttp
import json
import os
import sys
import time
import random
import string
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict, Any, Set
from collections import defaultdict

from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Prompt, Confirm, IntPrompt
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.live import Live
from rich.layout import Layout
from rich.text import Text
from rich.style import Style
from rich import box
from rich.tree import Tree

console = Console()

DISCORD_API = "https://discord.com/api/v10"
CONFIG_FILE = Path("discord_config.json")
EXPORT_DIR = Path("exports")
LOGS_DIR = Path("logs")


class DiscordClient:
    """Discord client using user token"""
    
    def __init__(self, token: str):
        self.token = token
        self.headers = {
            "Authorization": token,
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        self.session: Optional[aiohttp.ClientSession] = None
        self.user_info: Optional[Dict] = None
        self.guilds: List[Dict] = []
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession(headers=self.headers)
        return self
    
    async def __aexit__(self, *args):
        if self.session:
            await self.session.close()
    
    async def _request(self, method: str, endpoint: str, retries: int = 3, **kwargs) -> Optional[Any]:
        """Make API request with rate limit handling"""
        url = f"{DISCORD_API}{endpoint}"
        
        for attempt in range(retries):
            try:
                async with self.session.request(method, url, **kwargs) as response:
                    if response.status == 429:
                        retry_after = float(response.headers.get("Retry-After", 5))
                        console.print(f"[yellow]⚠ Rate limited. Waiting {retry_after:.1f}s...[/yellow]")
                        await asyncio.sleep(retry_after + 0.5)
                        continue
                    
                    if response.status == 200:
                        return await response.json()
                    elif response.status == 204:
                        return {"success": True}
                    elif response.status == 401:
                        return None
                    elif response.status == 403:
                        return None
                    else:
                        await asyncio.sleep(1)
                        continue
            except Exception as e:
                await asyncio.sleep(1)
        
        return None
    
    async def login(self) -> bool:
        """Verify token and get user info"""
        self.user_info = await self._request("GET", "/users/@me")
        return self.user_info is not None
    
    async def get_guilds(self) -> List[Dict]:
        """Get all guilds"""
        guilds = await self._request("GET", "/users/@me/guilds")
        if guilds:
            self.guilds = guilds
        return self.guilds or []
    
    async def get_guild_channels(self, guild_id: str) -> List[Dict]:
        """Get all channels in a guild"""
        return await self._request("GET", f"/guilds/{guild_id}/channels") or []
    
    async def get_channel_messages(self, channel_id: str, limit: int = 100, before: str = None) -> List[Dict]:
        """Get messages from a channel"""
        params = {"limit": min(100, limit)}
        if before:
            params["before"] = before
        return await self._request("GET", f"/channels/{channel_id}/messages", params=params) or []
    
    async def send_message(self, channel_id: str, content: str, reply_to: str = None) -> Optional[Dict]:
        """Send a message"""
        payload = {"content": content}
        if reply_to:
            payload["message_reference"] = {"message_id": reply_to}
        return await self._request("POST", f"/channels/{channel_id}/messages", json=payload)
    
    async def create_dm(self, user_id: str) -> Optional[Dict]:
        """Create DM channel with user"""
        return await self._request("POST", "/users/@me/channels", json={"recipient_id": user_id})
    
    async def send_dm(self, user_id: str, content: str) -> Optional[Dict]:
        """Send DM to user"""
        dm = await self.create_dm(user_id)
        if dm and dm.get("id"):
            return await self.send_message(dm["id"], content)
        return None
    
    async def get_reactions(self, channel_id: str, message_id: str, emoji: str, limit: int = 100) -> List[Dict]:
        """Get users who reacted with an emoji"""
        return await self._request(
            "GET", 
            f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}",
            params={"limit": min(100, limit)}
        ) or []
    
    async def add_reaction(self, channel_id: str, message_id: str, emoji: str) -> bool:
        """Add reaction to message"""
        result = await self._request("PUT", f"/channels/{channel_id}/messages/{message_id}/reactions/{emoji}/@me")
        return result is not None
    
    async def delete_message(self, channel_id: str, message_id: str) -> bool:
        """Delete a message"""
        result = await self._request("DELETE", f"/channels/{channel_id}/messages/{message_id}")
        return result is not None
    
    async def edit_message(self, channel_id: str, message_id: str, content: str) -> Optional[Dict]:
        """Edit a message"""
        return await self._request("PATCH", f"/channels/{channel_id}/messages/{message_id}", json={"content": content})
    
    async def get_guild_member(self, guild_id: str, user_id: str) -> Optional[Dict]:
        """Get specific guild member"""
        return await self._request("GET", f"/guilds/{guild_id}/members/{user_id}")
    
    async def search_guild_members(self, guild_id: str, query: str = "", limit: int = 1000) -> List[Dict]:
        """Search guild members"""
        return await self._request(
            "GET", f"/guilds/{guild_id}/members/search",
            params={"query": query, "limit": min(1000, limit)}
        ) or []
    
    async def get_user(self, user_id: str) -> Optional[Dict]:
        """Get user info"""
        return await self._request("GET", f"/users/{user_id}")
    
    async def typing(self, channel_id: str) -> bool:
        """Send typing indicator"""
        result = await self._request("POST", f"/channels/{channel_id}/typing")
        return result is not None
    
    async def get_guild_roles(self, guild_id: str) -> List[Dict]:
        """Get guild roles"""
        return await self._request("GET", f"/guilds/{guild_id}/roles") or []
    
    async def join_thread(self, thread_id: str) -> bool:
        """Join a thread"""
        result = await self._request("PUT", f"/channels/{thread_id}/thread-members/@me")
        return result is not None
    
    async def leave_guild(self, guild_id: str) -> bool:
        """Leave a guild"""
        result = await self._request("DELETE", f"/users/@me/guilds/{guild_id}")
        return result is not None


class DiscordTool:
    """Ultimate Discord Automation Tool"""
    
    def __init__(self):
        self.client: Optional[DiscordClient] = None
        self.config = self._load_config()
        self.selected_guild: Optional[Dict] = None
        self.selected_channels: List[Dict] = []
        self.scraped_users: Dict[str, Dict] = {}
        self.running = True
        
        EXPORT_DIR.mkdir(exist_ok=True)
        LOGS_DIR.mkdir(exist_ok=True)
    
    def _load_config(self) -> Dict:
        if CONFIG_FILE.exists():
            with open(CONFIG_FILE) as f:
                return json.load(f)
        return {"token": "", "message_delay_min": 1, "message_delay_max": 3}
    
    def _save_config(self):
        with open(CONFIG_FILE, "w") as f:
            json.dump(self.config, f, indent=2)
    
    def _log(self, action: str, details: str = ""):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_file = LOGS_DIR / f"log_{datetime.now().strftime('%Y%m%d')}.txt"
        with open(log_file, "a") as f:
            f.write(f"[{timestamp}] {action}: {details}\n")
    
    def show_banner(self):
        banner = """
    ██████╗ ██╗███████╗ ██████╗ ██████╗ ██████╗ ██████╗     ██╗   ██╗██╗  ████████╗██╗███╗   ███╗ █████╗ ████████╗███████╗
    ██╔══██╗██║██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔══██╗    ██║   ██║██║  ╚══██╔══╝██║████╗ ████║██╔══██╗╚══██╔══╝██╔════╝
    ██║  ██║██║███████╗██║     ██║   ██║██████╔╝██║  ██║    ██║   ██║██║     ██║   ██║██╔████╔██║███████║   ██║   █████╗  
    ██║  ██║██║╚════██║██║     ██║   ██║██╔══██╗██║  ██║    ██║   ██║██║     ██║   ██║██║╚██╔╝██║██╔══██║   ██║   ██╔══╝  
    ██████╔╝██║███████║╚██████╗╚██████╔╝██║  ██║██████╔╝    ╚██████╔╝███████╗██║   ██║██║ ╚═╝ ██║██║  ██║   ██║   ███████╗
    ╚═════╝ ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝      ╚═════╝ ╚══════╝╚═╝   ╚═╝╚═╝     ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝
        """
        console.print(Panel(Text(banner, style="bold cyan"), title="[bold magenta]★ ULTIMATE DISCORD TOOL ★[/bold magenta]", border_style="magenta"))
    
    def show_menu(self) -> str:
        menu = Table(box=box.DOUBLE_EDGE, show_header=False, border_style="cyan", padding=(0, 2))
        menu.add_column("", style="bold yellow", width=6)
        menu.add_column("", style="white", width=35)
        menu.add_column("", style="bold yellow", width=6)
        menu.add_column("", style="white", width=35)
        
        options = [
            ("1", "🔐 Token Setup", "2", "🖥️  Select Server"),
            ("3", "📋 SCRAPE ALL USERS", "4", "💬 Send Message"),
            ("5", "🔥 CHANNEL SPAMMER", "6", "📨 MASS DM SERVER"),
            ("7", "⏰ Scheduled Messages", "8", "📢 Mass Message All Channels"),
            ("9", "🎭 Raid Mode", "10", "💣 Nuke Channel"),
            ("11", "👻 Ghost Ping", "12", "🔄 Auto Responder"),
            ("13", "📝 Message Templates", "14", "🗑️  Purge My Messages"),
            ("15", "👀 Stalk User", "16", "📊 Server Info"),
            ("17", "🎲 Random Spam", "18", "⚡ Reaction Bomb"),
            ("19", "📜 View Logs", "20", "⚙️  Settings"),
            ("0", "🚪 EXIT", "", ""),
        ]
        
        for row in options:
            menu.add_row(f"[{row[0]}]", row[1], f"[{row[2]}]" if row[2] else "", row[3])
        
        console.print(Panel(menu, title="[bold green]★ MAIN MENU ★[/bold green]", border_style="green"))
        
        if self.client and self.client.user_info:
            console.print(f"[green]✓ Logged:[/green] [cyan]{self.client.user_info['username']}[/cyan]", end="  ")
        if self.selected_guild:
            console.print(f"[green]✓ Server:[/green] [magenta]{self.selected_guild['name'][:25]}[/magenta]", end="  ")
        if self.scraped_users:
            console.print(f"[green]✓ Scraped:[/green] [yellow]{len(self.scraped_users)} users[/yellow]", end="")
        console.print()
        
        return Prompt.ask("\n[bold yellow]►[/bold yellow]", default="0")
    
    async def set_token(self):
        console.print(Panel("[yellow]Enter your Discord USER token[/yellow]", border_style="yellow"))
        token = Prompt.ask("[bold]Token[/bold]", password=True)
        
        if not token:
            return
        
        with console.status("[cyan]Verifying...[/cyan]"):
            async with DiscordClient(token) as client:
                if await client.login():
                    self.client = client
                    self.config["token"] = token
                    self._save_config()
                    console.print(f"[green]✓ Logged in as {client.user_info['username']}![/green]")
                else:
                    console.print("[red]✖ Invalid token![/red]")
    
    async def select_server(self):
        if not self.client:
            console.print("[red]✖ Set token first![/red]")
            return
        
        guilds = await self.client.get_guilds()
        
        if not guilds:
            console.print("[red]✖ No servers found[/red]")
            return
        
        table = Table(title=f"[bold]Your Servers ({len(guilds)})[/bold]", box=box.ROUNDED, border_style="cyan")
        table.add_column("#", style="yellow", width=4)
        table.add_column("Server", style="white", width=30)
        table.add_column("ID", style="dim", width=20)
        table.add_column("Owner", style="magenta", width=6)
        
        for i, g in enumerate(guilds, 1):
            table.add_row(str(i), g["name"][:28], g["id"], "★" if g.get("owner") else "")
        
        console.print(table)
        
        choice = IntPrompt.ask("[bold]Select[/bold]", default=1)
        if 1 <= choice <= len(guilds):
            self.selected_guild = guilds[choice - 1]
            self.scraped_users = {}
            console.print(f"[green]✓ Selected: {self.selected_guild['name']}[/green]")
    
    async def scrape_all_users(self):
        """ULTIMATE USER SCRAPER - Scans everything"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        console.print(Panel(
            "[bold cyan]★ ULTIMATE USER SCRAPER ★[/bold cyan]\n\n"
            "[white]This will scan:[/white]\n"
            "• All channel messages\n"
            "• All reactions\n"
            "• Message authors & mentions\n"
            "• Thread participants\n\n"
            "[yellow]This may take a while for large servers![/yellow]",
            border_style="cyan"
        ))
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") in [0, 5, 11, 12]]  # text, news, threads
        
        console.print(f"[cyan]Found {len(text_channels)} channels to scan[/cyan]")
        
        messages_per_channel = IntPrompt.ask("[bold]Messages per channel[/bold]", default=500)
        
        if not Confirm.ask("[bold]Start scraping?[/bold]"):
            return
        
        users: Dict[str, Dict] = {}
        total_messages = 0
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TaskProgressColumn(),
            console=console
        ) as progress:
            main_task = progress.add_task("[cyan]Scanning channels...", total=len(text_channels))
            
            for channel in text_channels:
                progress.update(main_task, description=f"[cyan]#{channel.get('name', 'unknown')[:20]}")
                
                try:
                    before = None
                    channel_msgs = 0
                    
                    while channel_msgs < messages_per_channel:
                        messages = await self.client.get_channel_messages(
                            channel["id"], 
                            limit=100,
                            before=before
                        )
                        
                        if not messages:
                            break
                        
                        for msg in messages:
                            total_messages += 1
                            channel_msgs += 1
                            
                            # Get author
                            author = msg.get("author", {})
                            if author.get("id") and not author.get("bot"):
                                uid = author["id"]
                                if uid not in users:
                                    users[uid] = {
                                        "id": uid,
                                        "username": author.get("username", "unknown"),
                                        "discriminator": author.get("discriminator", "0"),
                                        "global_name": author.get("global_name"),
                                        "avatar": author.get("avatar"),
                                        "messages": 0,
                                        "first_seen": msg.get("timestamp"),
                                        "channels": set()
                                    }
                                users[uid]["messages"] += 1
                                users[uid]["channels"].add(channel.get("name", "unknown"))
                            
                            # Get mentions
                            for mention in msg.get("mentions", []):
                                if mention.get("id") and not mention.get("bot"):
                                    mid = mention["id"]
                                    if mid not in users:
                                        users[mid] = {
                                            "id": mid,
                                            "username": mention.get("username", "unknown"),
                                            "discriminator": mention.get("discriminator", "0"),
                                            "global_name": mention.get("global_name"),
                                            "avatar": mention.get("avatar"),
                                            "messages": 0,
                                            "first_seen": msg.get("timestamp"),
                                            "channels": set()
                                        }
                            
                            # Get reactions
                            for reaction in msg.get("reactions", []):
                                emoji = reaction.get("emoji", {})
                                emoji_str = emoji.get("name", "")
                                if emoji.get("id"):
                                    emoji_str = f"{emoji['name']}:{emoji['id']}"
                                
                                try:
                                    reactors = await self.client.get_reactions(
                                        channel["id"], msg["id"], emoji_str, 100
                                    )
                                    for reactor in reactors:
                                        if reactor.get("id") and not reactor.get("bot"):
                                            rid = reactor["id"]
                                            if rid not in users:
                                                users[rid] = {
                                                    "id": rid,
                                                    "username": reactor.get("username", "unknown"),
                                                    "discriminator": reactor.get("discriminator", "0"),
                                                    "global_name": reactor.get("global_name"),
                                                    "avatar": reactor.get("avatar"),
                                                    "messages": 0,
                                                    "first_seen": msg.get("timestamp"),
                                                    "channels": set()
                                                }
                                except:
                                    pass
                        
                        before = messages[-1]["id"]
                        await asyncio.sleep(0.3)
                    
                except Exception as e:
                    pass
                
                progress.advance(main_task)
                await asyncio.sleep(0.2)
        
        # Convert sets to lists for JSON
        for uid in users:
            users[uid]["channels"] = list(users[uid]["channels"])
        
        self.scraped_users = users
        
        # Export to TXT
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = EXPORT_DIR / f"{self.selected_guild['name'].replace(' ', '_')}_{timestamp}.txt"
        
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"# Server: {self.selected_guild['name']}\n")
            f.write(f"# Exported: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"# Total Users: {len(users)}\n")
            f.write(f"# Messages Scanned: {total_messages}\n")
            f.write(f"# Format: username:userid:messages|channels|global_name\n")
            f.write("=" * 80 + "\n\n")
            
            for uid, user in sorted(users.items(), key=lambda x: x[1]["messages"], reverse=True):
                username = user["username"]
                disc = user["discriminator"]
                msgs = user["messages"]
                chans = len(user["channels"])
                gname = user.get("global_name") or "none"
                f.write(f"{username}#{disc}:{uid}:{msgs}msgs|{chans}chans|{gname}\n")
        
        console.print(Panel(
            f"[bold green]★ SCRAPE COMPLETE ★[/bold green]\n\n"
            f"[white]Users Found:[/white] [cyan]{len(users)}[/cyan]\n"
            f"[white]Messages Scanned:[/white] [cyan]{total_messages}[/cyan]\n"
            f"[white]File:[/white] [yellow]{filename}[/yellow]",
            border_style="green"
        ))
        self._log("SCRAPE", f"{len(users)} users from {self.selected_guild['name']}")
    
    async def send_message_menu(self):
        """Send single message"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        table = Table(box=box.ROUNDED, border_style="cyan")
        table.add_column("#", style="yellow", width=4)
        table.add_column("Channel", style="white")
        
        for i, ch in enumerate(text_channels[:30], 1):
            table.add_row(str(i), f"#{ch['name']}")
        
        console.print(table)
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        if not (1 <= choice <= len(text_channels)):
            return
        
        channel = text_channels[choice - 1]
        content = Prompt.ask("[bold]Message[/bold]")
        
        if content:
            result = await self.client.send_message(channel["id"], content)
            if result:
                console.print(f"[green]✓ Sent to #{channel['name']}[/green]")
    
    async def channel_spammer(self):
        """Spam a single channel"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        console.print(Panel(
            "[bold red]★ CHANNEL SPAMMER ★[/bold red]\n\n"
            "[yellow]⚠ Use responsibly! May result in ban![/yellow]",
            border_style="red"
        ))
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:30], 1):
            console.print(f"[yellow][{i}][/yellow] #{ch['name']}")
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        if not (1 <= choice <= len(text_channels)):
            return
        
        channel = text_channels[choice - 1]
        
        console.print("\n[1] Single message spam")
        console.print("[2] Multiple messages (different each time)")
        console.print("[3] Random text spam")
        
        mode = Prompt.ask("[bold]Mode[/bold]", choices=["1", "2", "3"], default="1")
        
        messages = []
        if mode == "1":
            msg = Prompt.ask("[bold]Message[/bold]")
            messages = [msg]
        elif mode == "2":
            console.print("[dim]Enter messages (empty line to finish)[/dim]")
            while True:
                msg = Prompt.ask("[bold]Message[/bold]", default="")
                if not msg:
                    break
                messages.append(msg)
        else:
            messages = None  # Random
        
        count = IntPrompt.ask("[bold]Number of messages[/bold]", default=10)
        delay_min = IntPrompt.ask("[bold]Min delay (seconds)[/bold]", default=1)
        delay_max = IntPrompt.ask("[bold]Max delay (seconds)[/bold]", default=3)
        
        if not Confirm.ask(f"[bold]Spam #{channel['name']} with {count} messages?[/bold]"):
            return
        
        sent = 0
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), BarColumn(), TaskProgressColumn(), console=console) as progress:
            task = progress.add_task(f"[red]Spamming #{channel['name']}...", total=count)
            
            for i in range(count):
                if messages:
                    content = random.choice(messages)
                else:
                    content = ''.join(random.choices(string.ascii_letters + string.digits + " ", k=random.randint(10, 50)))
                
                result = await self.client.send_message(channel["id"], content)
                if result:
                    sent += 1
                
                progress.advance(task)
                delay = random.uniform(delay_min, delay_max)
                await asyncio.sleep(delay)
        
        console.print(f"[green]✓ Sent {sent}/{count} messages[/green]")
        self._log("SPAM", f"#{channel['name']}: {sent} messages")
    
    async def mass_dm(self):
        """Mass DM all scraped users"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        if not self.scraped_users:
            console.print("[yellow]⚠ No users scraped! Run 'SCRAPE ALL USERS' first.[/yellow]")
            if Confirm.ask("[bold]Scrape users now?[/bold]"):
                await self.scrape_all_users()
            else:
                return
        
        console.print(Panel(
            f"[bold magenta]★ MASS DM ★[/bold magenta]\n\n"
            f"[white]Users available:[/white] [cyan]{len(self.scraped_users)}[/cyan]\n\n"
            "[yellow]⚠ Discord heavily rate limits DMs![/yellow]\n"
            "[yellow]⚠ Many users may have DMs closed![/yellow]",
            border_style="magenta"
        ))
        
        content = Prompt.ask("[bold]DM Message[/bold]")
        if not content:
            return
        
        limit = IntPrompt.ask("[bold]Max DMs to send[/bold]", default=50)
        delay_min = IntPrompt.ask("[bold]Min delay (seconds)[/bold]", default=3)
        delay_max = IntPrompt.ask("[bold]Max delay (seconds)[/bold]", default=10)
        
        if not Confirm.ask(f"[bold]Send DM to up to {limit} users?[/bold]"):
            return
        
        users_list = list(self.scraped_users.values())[:limit]
        sent = 0
        failed = 0
        
        with Progress(SpinnerColumn(), TextColumn("{task.description}"), BarColumn(), TaskProgressColumn(), console=console) as progress:
            task = progress.add_task("[magenta]Sending DMs...", total=len(users_list))
            
            for user in users_list:
                progress.update(task, description=f"[magenta]DM @{user['username'][:15]}...")
                
                result = await self.client.send_dm(user["id"], content)
                
                if result:
                    sent += 1
                    console.print(f"[green]✓ DM sent to {user['username']}[/green]")
                else:
                    failed += 1
                
                progress.advance(task)
                delay = random.uniform(delay_min, delay_max)
                await asyncio.sleep(delay)
        
        console.print(Panel(
            f"[bold green]★ MASS DM COMPLETE ★[/bold green]\n\n"
            f"[green]Sent:[/green] {sent}\n"
            f"[red]Failed:[/red] {failed}",
            border_style="green"
        ))
        self._log("MASS_DM", f"Sent: {sent}, Failed: {failed}")
    
    async def scheduled_messages(self):
        """Schedule messages at intervals"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:20], 1):
            console.print(f"[{i}] #{ch['name']}")
        
        selection = Prompt.ask("[bold]Channels (comma-sep or 'all')[/bold]", default="1")
        
        if selection.lower() == "all":
            selected = text_channels
        else:
            indices = [int(x.strip()) - 1 for x in selection.split(",") if x.strip().isdigit()]
            selected = [text_channels[i] for i in indices if 0 <= i < len(text_channels)]
        
        content = Prompt.ask("[bold]Message[/bold]")
        delay = IntPrompt.ask("[bold]Interval (seconds)[/bold]", default=60)
        count = IntPrompt.ask("[bold]Times (0=infinite)[/bold]", default=10)
        
        if not Confirm.ask("[bold]Start?[/bold]"):
            return
        
        sent = 0
        target = count if count > 0 else float('inf')
        
        console.print("[yellow]Press Ctrl+C to stop[/yellow]")
        
        try:
            while sent < target:
                for ch in selected:
                    if sent >= target:
                        break
                    result = await self.client.send_message(ch["id"], content)
                    if result:
                        sent += 1
                        console.print(f"[green]✓ [{sent}] #{ch['name']}[/green]")
                    await asyncio.sleep(delay)
        except KeyboardInterrupt:
            pass
        
        console.print(f"[green]✓ Sent {sent} messages[/green]")
    
    async def mass_message_all_channels(self):
        """Message all channels"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        console.print(f"[cyan]Found {len(text_channels)} text channels[/cyan]")
        
        content = Prompt.ask("[bold]Message[/bold]")
        delay = IntPrompt.ask("[bold]Delay between channels (s)[/bold]", default=2)
        
        if not Confirm.ask("[bold red]Send to ALL channels?[/bold red]"):
            return
        
        sent = 0
        for ch in text_channels:
            result = await self.client.send_message(ch["id"], content)
            if result:
                sent += 1
                console.print(f"[green]✓ #{ch['name']}[/green]")
            await asyncio.sleep(delay)
        
        console.print(f"[green]✓ Sent to {sent}/{len(text_channels)} channels[/green]")
    
    async def raid_mode(self):
        """Raid mode - aggressive spam"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        console.print(Panel(
            "[bold red]★ RAID MODE ★[/bold red]\n\n"
            "[red]⚠ EXTREME WARNING![/red]\n"
            "This will spam ALL channels simultaneously!\n"
            "You WILL likely get banned!\n\n"
            "[yellow]Only use on servers you don't care about![/yellow]",
            border_style="red"
        ))
        
        if not Confirm.ask("[bold red]I understand the risks[/bold red]"):
            return
        
        if Prompt.ask("[bold]Type 'RAID' to confirm[/bold]") != "RAID":
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        content = Prompt.ask("[bold]Raid message[/bold]")
        rounds = IntPrompt.ask("[bold]Rounds[/bold]", default=5)
        
        for r in range(rounds):
            console.print(f"[red]Round {r+1}/{rounds}[/red]")
            tasks = []
            for ch in text_channels:
                tasks.append(self.client.send_message(ch["id"], content))
            await asyncio.gather(*tasks, return_exceptions=True)
            await asyncio.sleep(0.5)
        
        console.print("[red]★ Raid complete ★[/red]")
    
    async def nuke_channel(self):
        """Delete your messages in a channel"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:20], 1):
            console.print(f"[{i}] #{ch['name']}")
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        if not (1 <= choice <= len(text_channels)):
            return
        
        channel = text_channels[choice - 1]
        
        console.print(Panel(
            "[bold red]★ NUKE CHANNEL ★[/bold red]\n\n"
            "Options:\n"
            "[1] Spam then delete (ghost nuke)\n"
            "[2] Just spam massively\n"
            "[3] Delete my messages only",
            border_style="red"
        ))
        
        mode = Prompt.ask("[bold]Mode[/bold]", choices=["1", "2", "3"], default="2")
        
        if mode in ["1", "2"]:
            content = Prompt.ask("[bold]Spam message[/bold]", default="@everyone")
            count = IntPrompt.ask("[bold]Count[/bold]", default=20)
            
            message_ids = []
            for i in range(count):
                result = await self.client.send_message(channel["id"], content)
                if result:
                    message_ids.append(result["id"])
                    console.print(f"[red]💣 {i+1}/{count}[/red]")
                await asyncio.sleep(0.3)
            
            if mode == "1":
                console.print("[yellow]Deleting messages...[/yellow]")
                for mid in message_ids:
                    await self.client.delete_message(channel["id"], mid)
                    await asyncio.sleep(0.5)
        
        elif mode == "3":
            messages = await self.client.get_channel_messages(channel["id"], 100)
            my_id = self.client.user_info["id"]
            my_msgs = [m for m in messages if m.get("author", {}).get("id") == my_id]
            
            for msg in my_msgs:
                await self.client.delete_message(channel["id"], msg["id"])
                console.print(f"[red]🗑️ Deleted message[/red]")
                await asyncio.sleep(0.5)
        
        console.print("[green]✓ Done[/green]")
    
    async def ghost_ping(self):
        """Ghost ping users"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:20], 1):
            console.print(f"[{i}] #{ch['name']}")
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        channel = text_channels[choice - 1]
        
        console.print("\n[1] Ghost ping @everyone")
        console.print("[2] Ghost ping specific user")
        console.print("[3] Ghost ping from scraped users")
        
        mode = Prompt.ask("[bold]Mode[/bold]", choices=["1", "2", "3"], default="1")
        
        if mode == "1":
            ping = "@everyone"
        elif mode == "2":
            user_id = Prompt.ask("[bold]User ID[/bold]")
            ping = f"<@{user_id}>"
        else:
            if not self.scraped_users:
                console.print("[red]✖ No scraped users![/red]")
                return
            count = IntPrompt.ask("[bold]How many users[/bold]", default=5)
            users = list(self.scraped_users.keys())[:count]
            ping = " ".join([f"<@{u}>" for u in users])
        
        times = IntPrompt.ask("[bold]Times[/bold]", default=3)
        
        for i in range(times):
            result = await self.client.send_message(channel["id"], ping)
            if result:
                await asyncio.sleep(0.3)
                await self.client.delete_message(channel["id"], result["id"])
                console.print(f"[cyan]👻 Ghost ping {i+1}[/cyan]")
            await asyncio.sleep(1)
    
    async def auto_responder(self):
        """Setup auto responses"""
        console.print(Panel(
            "[cyan]Auto Responder Setup[/cyan]\n\n"
            "Set trigger words and responses.\n"
            "[yellow]Requires keeping tool running![/yellow]",
            border_style="cyan"
        ))
        
        if "auto_responses" not in self.config:
            self.config["auto_responses"] = {}
        
        console.print("\n[1] Add trigger")
        console.print("[2] Remove trigger")
        console.print("[3] View triggers")
        console.print("[4] Start monitoring")
        
        choice = Prompt.ask("[bold]Option[/bold]", choices=["1", "2", "3", "4"], default="3")
        
        if choice == "1":
            trigger = Prompt.ask("[bold]Trigger word[/bold]").lower()
            response = Prompt.ask("[bold]Response[/bold]")
            self.config["auto_responses"][trigger] = response
            self._save_config()
            console.print("[green]✓ Added[/green]")
        
        elif choice == "2":
            trigger = Prompt.ask("[bold]Trigger to remove[/bold]")
            if trigger in self.config["auto_responses"]:
                del self.config["auto_responses"][trigger]
                self._save_config()
        
        elif choice == "3":
            for t, r in self.config.get("auto_responses", {}).items():
                console.print(f"[yellow]{t}[/yellow] → [white]{r}[/white]")
        
        elif choice == "4":
            console.print("[yellow]Auto responder monitoring not implemented in this version[/yellow]")
    
    async def message_templates(self):
        """Manage message templates"""
        if "templates" not in self.config:
            self.config["templates"] = []
        
        console.print("[1] Add template")
        console.print("[2] View templates")
        console.print("[3] Delete template")
        
        choice = Prompt.ask("[bold]Option[/bold]", choices=["1", "2", "3"], default="2")
        
        if choice == "1":
            tmpl = Prompt.ask("[bold]Template[/bold]")
            self.config["templates"].append(tmpl)
            self._save_config()
        elif choice == "2":
            for i, t in enumerate(self.config["templates"], 1):
                console.print(f"[{i}] {t[:50]}...")
        elif choice == "3":
            idx = IntPrompt.ask("[bold]Number[/bold]", default=1)
            if 1 <= idx <= len(self.config["templates"]):
                self.config["templates"].pop(idx - 1)
                self._save_config()
    
    async def purge_my_messages(self):
        """Delete your messages from a channel"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:20], 1):
            console.print(f"[{i}] #{ch['name']}")
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        channel = text_channels[choice - 1]
        
        my_id = self.client.user_info["id"]
        deleted = 0
        
        console.print("[yellow]Scanning and deleting...[/yellow]")
        
        before = None
        while True:
            messages = await self.client.get_channel_messages(channel["id"], 100, before)
            if not messages:
                break
            
            for msg in messages:
                if msg.get("author", {}).get("id") == my_id:
                    if await self.client.delete_message(channel["id"], msg["id"]):
                        deleted += 1
                        console.print(f"[red]🗑️ Deleted ({deleted})[/red]")
                    await asyncio.sleep(0.5)
            
            before = messages[-1]["id"]
            await asyncio.sleep(0.3)
        
        console.print(f"[green]✓ Deleted {deleted} messages[/green]")
    
    async def stalk_user(self):
        """Get info about a user"""
        if not self.client:
            console.print("[red]✖ Set token first![/red]")
            return
        
        user_id = Prompt.ask("[bold]User ID[/bold]")
        
        user = await self.client.get_user(user_id)
        
        if not user:
            console.print("[red]✖ User not found[/red]")
            return
        
        console.print(Panel(
            f"[bold]Username:[/bold] {user.get('username')}#{user.get('discriminator', '0')}\n"
            f"[bold]Global Name:[/bold] {user.get('global_name', 'N/A')}\n"
            f"[bold]ID:[/bold] {user.get('id')}\n"
            f"[bold]Bot:[/bold] {user.get('bot', False)}\n"
            f"[bold]Avatar:[/bold] {user.get('avatar', 'None')}\n"
            f"[bold]Banner:[/bold] {user.get('banner', 'None')}\n"
            f"[bold]Accent Color:[/bold] {user.get('accent_color', 'None')}",
            title=f"User: {user.get('username')}",
            border_style="cyan"
        ))
    
    async def server_info(self):
        """Get server info"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        roles = await self.client.get_guild_roles(self.selected_guild["id"])
        
        text = len([c for c in channels if c.get("type") == 0])
        voice = len([c for c in channels if c.get("type") == 2])
        categories = len([c for c in channels if c.get("type") == 4])
        
        console.print(Panel(
            f"[bold]Name:[/bold] {self.selected_guild['name']}\n"
            f"[bold]ID:[/bold] {self.selected_guild['id']}\n"
            f"[bold]Owner:[/bold] {'Yes' if self.selected_guild.get('owner') else 'No'}\n"
            f"[bold]Text Channels:[/bold] {text}\n"
            f"[bold]Voice Channels:[/bold] {voice}\n"
            f"[bold]Categories:[/bold] {categories}\n"
            f"[bold]Roles:[/bold] {len(roles)}\n"
            f"[bold]Scraped Users:[/bold] {len(self.scraped_users)}",
            title=f"Server: {self.selected_guild['name']}",
            border_style="cyan"
        ))
    
    async def random_spam(self):
        """Random text spam"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:20], 1):
            console.print(f"[{i}] #{ch['name']}")
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        channel = text_channels[choice - 1]
        
        console.print("\n[1] Random letters")
        console.print("[2] Random emojis")
        console.print("[3] Random copypasta")
        console.print("[4] Zalgo text")
        
        mode = Prompt.ask("[bold]Mode[/bold]", choices=["1", "2", "3", "4"], default="1")
        count = IntPrompt.ask("[bold]Count[/bold]", default=10)
        
        emojis = "😀😂🤣😍🥰😎🤯🥳🤮💀👻🔥💯🎉🚀💎🌈⭐🍕🎮"
        copypastas = [
            "I just mass DMed your entire server 😎",
            "Your server is now under my control 🎮",
            "imagine being this bad at discord moderation 💀",
            "This server is now property of me",
            "L + ratio + you fell off",
        ]
        
        zalgo_chars = ['\u0300', '\u0301', '\u0302', '\u0303', '\u0304', '\u0305', '\u0306', '\u0307', '\u0308', '\u0309']
        
        for i in range(count):
            if mode == "1":
                content = ''.join(random.choices(string.ascii_letters + string.digits, k=random.randint(20, 100)))
            elif mode == "2":
                content = ''.join(random.choices(emojis, k=random.randint(10, 30)))
            elif mode == "3":
                content = random.choice(copypastas)
            else:
                base = ''.join(random.choices(string.ascii_letters, k=20))
                content = ''.join(c + ''.join(random.choices(zalgo_chars, k=random.randint(1, 5))) for c in base)
            
            result = await self.client.send_message(channel["id"], content)
            if result:
                console.print(f"[green]✓ {i+1}/{count}[/green]")
            await asyncio.sleep(random.uniform(0.5, 2))
    
    async def reaction_bomb(self):
        """Add many reactions to a message"""
        if not self.client or not self.selected_guild:
            console.print("[red]✖ Set token and select server first![/red]")
            return
        
        channels = await self.client.get_guild_channels(self.selected_guild["id"])
        text_channels = [c for c in channels if c.get("type") == 0]
        
        for i, ch in enumerate(text_channels[:20], 1):
            console.print(f"[{i}] #{ch['name']}")
        
        choice = IntPrompt.ask("[bold]Channel[/bold]", default=1)
        channel = text_channels[choice - 1]
        
        message_id = Prompt.ask("[bold]Message ID[/bold]")
        
        emojis = ["😀", "😂", "🤣", "😍", "🥰", "😎", "🤯", "🥳", "💀", "👻", "🔥", "💯", "🎉", "🚀", "💎", "⭐", "🍕", "🎮", "❤️", "💙"]
        
        count = IntPrompt.ask("[bold]Reactions[/bold]", default=10)
        
        for emoji in emojis[:count]:
            result = await self.client.add_reaction(channel["id"], message_id, emoji)
            if result:
                console.print(f"[green]✓ Added {emoji}[/green]")
            await asyncio.sleep(0.3)
    
    def view_logs(self):
        """View logs"""
        log_files = list(LOGS_DIR.glob("log_*.txt"))
        if not log_files:
            console.print("[yellow]No logs[/yellow]")
            return
        
        latest = sorted(log_files, reverse=True)[0]
        with open(latest) as f:
            lines = f.readlines()[-30:]
        
        for line in lines:
            console.print(f"[dim]{line.strip()}[/dim]")
    
    async def settings(self):
        """Settings"""
        console.print(Panel(
            f"[1] Clear token\n"
            f"[2] Set message delays ({self.config.get('message_delay_min', 1)}-{self.config.get('message_delay_max', 3)}s)\n"
            f"[3] Export config\n"
            f"[4] Clear scraped users",
            border_style="cyan"
        ))
        
        choice = Prompt.ask("[bold]Option[/bold]", choices=["1", "2", "3", "4"], default="2")
        
        if choice == "1":
            self.config["token"] = ""
            self._save_config()
            self.client = None
        elif choice == "2":
            self.config["message_delay_min"] = IntPrompt.ask("[bold]Min[/bold]", default=1)
            self.config["message_delay_max"] = IntPrompt.ask("[bold]Max[/bold]", default=3)
            self._save_config()
        elif choice == "3":
            console.print(f"[cyan]Config: {CONFIG_FILE.absolute()}[/cyan]")
        elif choice == "4":
            self.scraped_users = {}
            console.print("[green]✓ Cleared[/green]")
    
    async def run(self):
        """Main loop"""
        self.show_banner()
        
        # Auto-login
        if self.config.get("token"):
            async with DiscordClient(self.config["token"]) as client:
                if await client.login():
                    self.client = client
                    console.print(f"[green]✓ Auto-logged in as {client.user_info['username']}[/green]")
                    
                    while self.running:
                        try:
                            choice = self.show_menu()
                            
                            actions = {
                                "0": lambda: setattr(self, 'running', False),
                                "1": self.set_token,
                                "2": self.select_server,
                                "3": self.scrape_all_users,
                                "4": self.send_message_menu,
                                "5": self.channel_spammer,
                                "6": self.mass_dm,
                                "7": self.scheduled_messages,
                                "8": self.mass_message_all_channels,
                                "9": self.raid_mode,
                                "10": self.nuke_channel,
                                "11": self.ghost_ping,
                                "12": self.auto_responder,
                                "13": self.message_templates,
                                "14": self.purge_my_messages,
                                "15": self.stalk_user,
                                "16": self.server_info,
                                "17": self.random_spam,
                                "18": self.reaction_bomb,
                                "19": lambda: self.view_logs(),
                                "20": self.settings,
                            }
                            
                            action = actions.get(choice)
                            if action:
                                if asyncio.iscoroutinefunction(action):
                                    await action()
                                else:
                                    action()
                            
                            if self.running:
                                input("\n[Enter to continue]")
                                console.clear()
                                self.show_banner()
                        
                        except KeyboardInterrupt:
                            self.running = False
                    
                    return
        
        # No token
        while self.running:
            choice = self.show_menu()
            if choice == "0":
                break
            elif choice == "1":
                await self.set_token()
                if self.client:
                    await self.run()
                    return
            else:
                console.print("[yellow]Set token first![/yellow]")
            input("\n[Enter]")
            console.clear()
            self.show_banner()
        
        console.print("[bold green]Goodbye![/bold green]")


async def main():
    tool = DiscordTool()
    await tool.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\nBye!")
